
package proyectogit;

import java.util.Scanner;

/**
 *
 * @author TheAl
 */
public class ProyectoGIT {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        
        Scanner lector = new Scanner(System.in);
        
            System.out.println("Escribe tu nombre");
            
            String nombre = lector.nextLine();
            
                System.out.println("Tu Nombre es: " + nombre);
            
    }
    
}
